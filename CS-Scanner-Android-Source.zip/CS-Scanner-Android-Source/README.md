# CS Scanner (Android starter project)

An Android Studio Kotlin/Jetpack Compose starter app for authorized inventory of devices on your own Wi-Fi/LAN.

## Included
- Local IPv4 /24 scan with short TCP probes on common management/service ports
- Inventory list with editable category, model number, serial number and notes
- CSV inventory export (saved in the app-specific external files directory)
- Credential vault storing manually entered username/password pairs encrypted using AES-GCM with a non-exportable Android Keystore key

## Build
1. Open this folder in Android Studio (recent version with Android Gradle Plugin 8.7 support).
2. Allow Gradle sync.
3. Connect an Android phone to the LAN you administer.
4. Run the `app` configuration.

## Important limitations
- Android and Wi-Fi routers may block or rate-limit LAN probes. A device that does not respond may still be present.
- This starter scans the phone's current IPv4 /24 subnet only; it does not scan VLANs, guest networks, or remote networks.
- IP, hostname and responding ports do not reliably reveal a device's exact model or serial number. Those fields are editable inventory fields. For automatic enrichment, add authorized integrations such as SNMPv3, SSH, ONVIF, vendor APIs, or router DHCP/client-list APIs.
- MAC addresses are not reliably available to ordinary Android apps on modern Android versions, so this starter leaves them blank rather than guessing.
- Passwords are not extracted, guessed, tested, or transmitted. The vault stores credentials you enter; this starter does not yet implement device login or credential retrieval.
- Scanning should be limited to networks and devices you own or are explicitly authorized to administer.

## Next production steps
- Add a foreground service and progress/cancellation for long scans.
- Add SNMPv3 and ONVIF discovery with explicit per-device authorization.
- Add biometric/device-credential gate before vault access, credential editing and export.
- Add Room database persistence, encrypted backups and a searchable audit trail.
- Move CSV export to Android's Storage Access Framework for user-selected destinations.
