package com.example.ipdevicescanner

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.Inet4Address

object NetworkScanner {
    private val ports = listOf(22, 23, 80, 443, 445, 554, 8080, 8443)

    @Suppress("DEPRECATION")
    suspend fun scan(context: Context): List<Device> = coroutineScope {
        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val info = wifi.connectionInfo
        val ip = info.ipAddress
        if (ip == 0) return@coroutineScope emptyList()
        val prefix = (0..3).joinToString(".") { ((ip shr (it * 8)) and 0xff).toString() }
        val candidates = (1..254).map { "$prefix.$it" }.filter { it != prefix }
        candidates.map { host ->
            async {
                try {
                    val address = InetAddress.getByName(host)
                    // A short TCP connect sweep is more reliable than ICMP on many Android networks.
                    val open = ports.filter { port ->
                        try {
                            Socket().use { s -> s.connect(InetSocketAddress(host, port), 180); true }
                        } catch (_: Exception) { false }
                    }
                    val alive = address.isReachable(350) || open.isNotEmpty()
                    if (alive) Device(
                        ip = host,
                        hostname = try { address.canonicalHostName.takeIf { it != host } ?: "" } catch (_: Exception) { "" },
                        openPorts = open.joinToString(",")
                    ) else null
                } catch (_: Exception) { null }
            }
        }.awaitAll().filterNotNull().sortedBy { it.ip.substringAfterLast('.').toIntOrNull() ?: 0 }
    }
}
