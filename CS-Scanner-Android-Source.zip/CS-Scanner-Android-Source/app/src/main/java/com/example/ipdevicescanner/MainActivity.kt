package com.example.ipdevicescanner

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Device(
    val ip: String,
    val hostname: String = "",
    val mac: String = "",
    val openPorts: String = "",
    var category: String = "Unknown",
    var model: String = "",
    var serial: String = "",
    var notes: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { ScannerScreen() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var devices by remember { mutableStateOf(listOf<Device>()) }
    var scanning by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Connect to the Wi-Fi/LAN you own or administer.") }
    var selected by remember { mutableStateOf<Device?>(null) }
    var credentialLabel by remember { mutableStateOf("") }
    var credentialUser by remember { mutableStateOf("") }
    var credentialPass by remember { mutableStateOf("") }
    var showVault by remember { mutableStateOf(false) }

    Scaffold(topBar = { TopAppBar(title = { Text("CS Scanner") }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
            Text("Local network inventory", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Text(status, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = !scanning, onClick = {
                    scanning = true
                    status = "Scanning local subnet…"
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            NetworkScanner.scan(context)
                        }
                        devices = result
                        scanning = false
                        status = "Found ${result.size} responding device(s). Some devices may not respond to probes."
                    }) { Text(if (scanning) "Scanning…" else "Scan LAN") }
                }
                OutlinedButton(onClick = { exportCsv(context, devices); status = "CSV report exported to Downloads." },
                    enabled = devices.isNotEmpty()) { Text("Export CSV") }
            }
            Spacer(Modifier.height(12.dp))
            Text("Devices (${devices.size})", style = MaterialTheme.typography.titleSmall)
            LazyColumn(Modifier.weight(1f)) {
                items(devices, key = { it.ip }) { d ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        onClick = { selected = d }) {
                        Column(Modifier.padding(12.dp)) {
                            Text(d.hostname.ifBlank { "Unknown device" }, style = MaterialTheme.typography.titleSmall)
                            Text("IP: ${d.ip}  •  Ports: ${d.openPorts.ifBlank { "not detected" }}")
                            Text("Category: ${d.category}  •  Model: ${d.model.ifBlank { "not recorded" }}")
                            Text("Serial: ${d.serial.ifBlank { "not recorded" }}")
                        }
                    }
                }
            }
            OutlinedButton(onClick = { showVault = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Credential vault")
            }
        }
    }

    selected?.let { d ->
        var category by remember(d.ip) { mutableStateOf(d.category) }
        var model by remember(d.ip) { mutableStateOf(d.model) }
        var serial by remember(d.ip) { mutableStateOf(d.serial) }
        var notes by remember(d.ip) { mutableStateOf(d.notes) }
        AlertDialog(onDismissRequest = { selected = null },
            title = { Text("Device details — ${d.ip}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(category, { category = it }, label = { Text("Device type") })
                    OutlinedTextField(model, { model = it }, label = { Text("Model number") })
                    OutlinedTextField(serial, { serial = it }, label = { Text("Serial number") })
                    OutlinedTextField(notes, { notes = it }, label = { Text("Notes") })
                    Text("MAC address: ${d.mac.ifBlank { "Not available" }}")
                    Text("Open ports: ${d.openPorts.ifBlank { "Not detected" }}")
                }
            },
            confirmButton = { TextButton(onClick = {
                devices = devices.map { if (it.ip == d.ip) it.copy(category=category, model=model, serial=serial, notes=notes) else it }
                selected = null
            }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { selected = null }) { Text("Cancel") } })
    }

    if (showVault) {
        AlertDialog(onDismissRequest = { showVault = false },
            title = { Text("Secure credential vault") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Store only credentials you are authorized to use. Values are encrypted with an Android Keystore key on this device.")
                    OutlinedTextField(credentialLabel, { credentialLabel = it }, label = { Text("Device / IP label") })
                    OutlinedTextField(credentialUser, { credentialUser = it }, label = { Text("Username") })
                    OutlinedTextField(credentialPass, { credentialPass = it }, label = { Text("Password") })
                }
            },
            confirmButton = { TextButton(onClick = {
                if (credentialLabel.isNotBlank() && credentialPass.isNotBlank()) {
                    CredentialVault(context).save(credentialLabel, credentialUser, credentialPass)
                    credentialLabel = ""; credentialUser = ""; credentialPass = ""
                    showVault = false
                }
            }) { Text("Encrypt & save") } },
            dismissButton = { TextButton(onClick = { showVault = false }) { Text("Close") } })
    }
}

@Suppress("DEPRECATION")
fun exportCsv(context: Context, devices: List<Device>) {
    val header = "IP,Hostname,MAC,Ports,Category,Model,Serial,Notes\n"
    val rows = devices.joinToString("\n") {
        listOf(it.ip,it.hostname,it.mac,it.openPorts,it.category,it.model,it.serial,it.notes)
            .joinToString(",") { value -> "\"${value.replace("\"", "\"\"")}\"" }
    }
    val dir = context.getExternalFilesDir(null) ?: context.filesDir
    File(dir, "device-inventory-${SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())}.csv")
        .writeText(header + rows)
}

